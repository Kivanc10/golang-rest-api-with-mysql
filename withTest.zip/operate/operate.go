package main

import "kivancaydogmus.com/apps/userApp/route"

func main() {
	route.HandleRequest()
}
